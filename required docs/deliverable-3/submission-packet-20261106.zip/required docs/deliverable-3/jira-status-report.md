# Jira Dashboard and Project Status Report

## Repository-verifiable status

The repository contains planning Jira labels and local defect references, but no verified live Jira issue export, dashboard configuration, project key confirmation, or Jira-GitHub Development-panel evidence. No Jira writes were performed.

Read-only GitHub inspection verified one related development record:
`Manyruumpus/CS455-IITK-Campus-Duo-#2`, merged 15 October 2026, titled
`test(KAN-36): isolate booking concurrency tests`, with commit
`500f9e5d73e0a232113ba4ec27e643a53fd7a940`. This confirms GitHub history for
the concurrency work but does not verify the corresponding Jira issue or any
other local `KAN-*` reference.

## Draft dashboard layout

| Gadget/report | Data needed |
|---|---|
| Defects by status/severity | Live project key and issue statuses |
| Requirements traceability | Actual issue keys linked to requirements |
| Sprint burn-up | Actual sprint dates, estimates and assignees |
| GitHub development links | Real issue-key branch/commit/PR links |
| Test evidence | Evidence paths and execution timestamps |

## Required human/external actions

Confirm the actual Jira project key and permissions, verify the GitHub integration, update issue links/statuses using the six supported defect cases, and attach the evidence paths. Do not treat the local `KAN-*` labels or `BL-*` planning IDs as proof of live Jira records.
