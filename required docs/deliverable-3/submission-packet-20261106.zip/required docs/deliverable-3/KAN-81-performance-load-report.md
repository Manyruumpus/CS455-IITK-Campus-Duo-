# KAN-81 Performance and Load Baseline

**Status:** Harness prepared; execution blocked before provisioning. No
performance measurements or optimization results are claimed by this report.

On 6 November 2026, `node` and `k6` were available. PostgreSQL was reachable
on `127.0.0.1:5432` but required an administrator credential for the
read-only target probe. `psql` was not on `PATH` but exists at
`C:\Program Files\PostgreSQL\18\bin\psql.exe`. No Flyway executable was found
on `PATH` or in the inspected local tool locations. Therefore the performance
database state, migration state, smoke run, baseline run, and optimization
comparison remain unverified.

## Authoritative requirements

The applicable requirements are:

- **NFR-06, `required docs/01-requirements-and-use-cases.md:140`:**
  “Capacity baseline: 100 daily active users and 250 core
  transactions/day or documented equivalent.”
- **NFR-07, `required docs/01-requirements-and-use-cases.md:141`:**
  “Set p95 latency and throughput budgets with environment, dataset and
  concurrency before load testing.”

The proposal also requires realistic mixed read/write workload, latency
percentiles, throughput, bottleneck diagnosis, and before/after optimization
evidence (`required docs/main_proposal.md:199`). NFR-06 specifies daily
capacity, not a peak requests-per-second or concurrency target. NFR-07 does
not specify numeric p95/throughput budgets; any numeric acceptance threshold
used by the harness is provisional until approved.

## Prepared experiment

The harness measures the real `GET /api/booking/availability` route through a
dedicated local Node process and a disposable PostgreSQL database. The route
requires development-only `X-Campus-Duo-Test-Actor` authentication; the
fixture creates one synthetic active, verified student and twelve owned
available slots on one owned location. The k6 script validates HTTP 200,
response shape, request-ID format, and the presence of every expected slot.
Malformed JSON, missing slots, wrong status/data, and empty/wrong responses
increment `availability_correctness_failures` and fail the k6 threshold.

Workload profiles:

| Profile | Stages | Classification |
|---|---|---|
| `smoke` | 1 VU ramp for 5 seconds, hold 10 seconds, ramp down 5 seconds | Bounded harness validation assumption; not a requirement |
| `baseline` | 1 VU/30 seconds, 5 VUs/60 seconds, 10 VUs/60 seconds, ramp down 30 seconds | Staged experiment assumption; not a requirement |

The profiles are intentionally bounded and are not a claim that the system
meets NFR-06. Daily volume and peak load are separate: NFR-06 requires a
capacity model of 250 core transactions/day for 100 DAU, while these profiles
measure endpoint behavior under selected concurrent VUs. A future mixed
workload must map requests to that daily model before acceptance.

The script uses a separate bounded warm-up invocation, then a separate measured
invocation; warm-up output is stored separately and excluded from measured
percentiles, rate, errors, and correctness totals. The measured smoke phase is
20 seconds before graceful ramp-down. There is no think time or explicit pacing:
each VU loops as soon as its prior request completes, so achieved RPS is an
observed result rather than implied by VU count.

The script currently uses a **provisional** `p(95)<1000ms` threshold for
availability requests and zero HTTP/correctness failures. NFR-07 also requires
a throughput budget, but none is specified. The proposed minimum throughput
criterion is **pending approval**; it must be selected for the measured phase
after observing the achieved rate and agreeing whether a request-rate or
transaction-rate budget is appropriate. It must not be presented as an NFR.
The zero-failure criteria are harness integrity requirements; the 1000 ms
latency value is not specified by NFR-07 and must be approved or replaced
before claiming requirement compliance. p50, p95, p99, achieved rate, counts,
errors, correctness failures, timeouts, and dropped iterations are collected
from the k6 summary/JSON output.

## Isolation and prerequisites

`backend/scripts/performance/availability-fixture-setup.sql` and
`availability-fixture-cleanup.sql` reject `campus_duo_dev` and
`campus_duo_test`, require `campus_duo_migrator`, and use a per-run manifest
of fresh UUIDs plus an ownership identifier. Setup is transactional and
rejects collisions. Cleanup is authorized only after setup returns
successfully, revalidates ownership and exact IDs, and leaves data in place
when setup outcome is ambiguous. Cleanup failures remain visible.
`Invoke-AvailabilityPerformanceBaseline.ps1` preflights both roles and starts
the app with that database and `campus_duo_app`; it sanitizes database
credential environment variables before launching k6.

The performance-only `loopback-server.js` imports the built exported
`createApp`, binds the real app to `127.0.0.1`, writes a readiness file with
the actual address, and closes the real pool during orderly shutdown.
This launcher differs from `server.ts` only in explicit loopback binding and
readiness/shutdown orchestration; production source is unchanged.

Migrations V001–V008 require the existing `campus_duo_migrator` owner,
`btree_gist` in `public`, and the existing runtime-role model; the reviewed
SQL does not hard-code `campus_duo_dev` as the migration target. Database
creation still requires an administrator because the migrator role has
`NOCREATEDB`. Apply reviewed migrations and verify the disposable database
before running the wrapper. Confirm `k6` v2.3.0, `psql`, and Flyway are
available on PATH before execution; availability is an execution prerequisite,
not a recorded performance result.

## Pending results

| Field | Result |
|---|---|
| Run ID / evidence path | Pending |
| Git revision/worktree state | Pending |
| Node/k6/PostgreSQL versions | Pending |
| Machine characteristics | Pending |
| Fixture size and target database | Pending |
| Warm-up result | Pending |
| Measured duration/profile | Pending |
| Requests/achieved rate | Pending |
| p50/p95/p99 | Pending |
| HTTP errors/timeouts | Pending |
| Correctness failures | Pending |
| Dropped iterations | Pending |
| Bottleneck/query-plan evidence | Pending |
| Optimization and equivalent repeat | Pending |

No production query, index, pool-size, or application-code optimization is
included in this baseline. Any future optimization must use equivalent
fixture, workload, warm-up, and environment and include before/after evidence.

## Next runnable procedure

1. Verify the shared roles already exist with an administrator, without
   altering their passwords, privileges, or attributes. Ensure the
   administrator can create one database and install `btree_gist`; the
   migrator can own the `campus_duo` schema; and Flyway is available.
2. From `backend`, run `npm run build`. Ensure `node`, `psql`, and k6 v2.3.0
   are installed separately and available on PATH.
3. From the repository root, prepare only the allowlisted database. The
   script refuses an existing target and does not drop or overwrite:

   ```powershell
   .\backend\scripts\performance\Invoke-Prepare-PerformanceDatabase.ps1 `
     -PerformanceDatabase campus_duo_perf_20261103
   ```

   It creates the database as `campus_duo_migrator`, installs `btree_gist`
   as an administrator, creates the migrator-owned `campus_duo` schema before
   Flyway, and runs Flyway with an explicit target URL rather than the
   development `flyway.toml` URL. Flyway history/checksums are preserved; the
   script does not manually replay migrations.
   
   The first attempted provisioning exposed a bootstrap issue: the database
   and extension were created, but `campus_duo` was absent while Flyway had
   `createSchemas=false` and history configured inside that schema, producing
   SQLSTATE `3F000`. The observed target is now a partial state and must be
   resumed explicitly:

   ```powershell
   .\backend\scripts\performance\Invoke-Prepare-PerformanceDatabase.ps1 `
     -PerformanceDatabase campus_duo_perf_20261103 `
     -ResumePartialTarget
   ```

   Resume is allowlisted to this exact database and only accepts the reviewed
   partial state: owner `campus_duo_migrator`, `btree_gist` in `public`, no
   `campus_duo` schema, and no Flyway history rows. It refuses unexpected
   ownership, user objects, existing history, or ambiguous state; it never
   drops, cleans, baselines, repairs, or erases history. Runtime success of
   this resume has not yet been verified.

   Once the read-only diagnostic has passed every named structural check and
   the target's provenance has been confirmed, the separate initialized-empty
   history path is explicitly enabled with:

   ```powershell
   .\backend\scripts\performance\Invoke-Prepare-PerformanceDatabase.ps1 `
     -PerformanceDatabase campus_duo_perf_20261103 `
     -ResumeInitializedEmptyHistory
   ```

   This path re-queries the live target, reuses the compatibility evaluator,
   requires three interactive `YES` confirmations, preserves the existing
   empty Flyway table/indexes, and then runs normal versioned Flyway
   migrations. It is not enabled by `-ResumePartialTarget`.

   If resume reports `history state 'present:0'`, do not rerun it blindly.
   Run the read-only diagnostic instead:

   ```powershell
   .\backend\scripts\performance\Invoke-Diagnose-PerformanceDatabase.ps1 `
     -PerformanceDatabase campus_duo_perf_20261103
   ```

   The diagnostic reports the actual target identity, schema and ownership,
   extension state, application versus extension-owned objects, history
   relation type/owner/columns/constraints/indexes/rows/entries, and a
   structural initialized-but-unmigrated candidate result. That result does
   not establish provenance: an empty history table alone cannot prove that
   this database belongs to the experiment or that migrations were never
   applied and removed. The additional resume state remains disabled until
   the diagnostic output is reviewed and explicitly confirmed.

   A subsequent provisioning attempt did not produce a performance
   measurement: Flyway was invoked from the `database` working directory
   with an invalid relative migration location, so it validated zero
   migrations and reported the schema up to date; the script then reached
   an application-access check without an initialized `campus_duo_app`
   credential. This is recorded as a provisioning failure, not successful
   migration or performance evidence. The corrected script resolves the
   migration directory from its own location, requires V001-V008 to be
   present, fails on missing locations, verifies the complete successful
   history set and required application tables, and prompts separately
   for the application-role password before access validation.
4. From the repository root, run:

   ```powershell
   .\backend\scripts\performance\Invoke-AvailabilityPerformanceBaseline.ps1 `
     -PerformanceDatabase campus_duo_perf_20261103 -LoadProfile smoke
   ```

   The wrapper interactively requests the two disposable-role passwords,
   performs both database/role preflights, creates the exact fixture, starts
   the dedicated app on port 4400, runs k6, writes a unique evidence
   directory, stops only its app process, and attempts exact fixture cleanup.
4. Review the generated `run-metadata.json`, `k6-summary.json`,
   `k6-metrics.json`, app logs, and correctness/threshold outcome. Repeat
   with `-LoadProfile baseline` only after smoke succeeds and record results
   in this report.

The wrapper uses the loopback-only performance launcher, not `server.ts`.
Provisioning and smoke execution remain pending; no measurements are claimed.
