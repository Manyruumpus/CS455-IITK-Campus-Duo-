# Deliverable 3 Coverage Report

## Backend

Source: `evidence/backend-coverage/KAN-81-post-review-20261103-162511-954-05681db0/`.

| Metric | Result |
|---|---:|
| Statements | 90.98% |
| Branches | 87.65% |
| Functions | 82.50% |
| Lines | 91.66% |

The denominator is the backend TypeScript source selected by the Vitest V8 configuration. This report does not merge frontend mock coverage into backend percentages.

On 6 November 2026, the explicitly isolated mocked/unit subset passed 29/29 and produced a **subset-only** V8 result in the ignored local artifact `backend/coverage/coverage-summary.json`: statements 60.88%, branches 63.69%, functions 42.50%, and lines 61.88%. This is not comparable to the full 57-test checkpoint because database-backed suites were not executed.

## Frontend

The frontend has a verified 182-test run but no executed coverage command or coverage artifact in this checkpoint. The 182 tests should not be converted into a coverage percentage. The frontend scope remains mock-service/component focused; production API integration is unavailable by design.

The frontend coverage command was attempted on 6 November 2026 and was blocked because `@vitest/coverage-v8` is not present in `frontend/node_modules` or the frontend lockfile. No frontend percentage is claimed.

## Limitations

Coverage percentages do not prove browser layout, PostgreSQL restart recovery, production authentication, or load performance. Excluded/blocked areas are listed in `testing-report.md`.
