# Deliverable 3 Testing Report

## Backend

The post-review backend checkpoint reports 57 tests across 9 files, including availability, booking policy/service, audit, error handling, health failure, and real PostgreSQL concurrency coverage. The authoritative successful evidence is `evidence/backend-tests/KAN-81-backend-post-review-20261103-162511-954-05681db0.json`; the overwritten `KAN-81-backend-full-suite-20261103-160736-858.json` is not used as success evidence.

On 6 November 2026, `Set-Location backend; npm run build` passed. The isolated mocked/unit subset (`auth.test.ts`, `errorHandler.test.ts`, `booking.service.test.ts`, and `health.failure.test.ts`) passed **29/29**. The health integration test passed **1/1** when `PGDATABASE=campus_duo_test` and `PGUSER=campus_duo_app` were explicitly set.

The full DB-backed suite was attempted with `PGDATABASE=campus_duo_test` and failed before meaningful fixture execution because `CAMPUS_DUO_MIGRATOR_PASSWORD` was absent; 30 tests passed and 27 DB-backed tests were skipped/blocked by fixture setup. This current failure is environment evidence, not a regression result. The earlier 57/57 checkpoint remains historical evidence and is not claimed as a run against the current dirty worktree.

## Frontend

On 3 November 2026: `Set-Location frontend; npm test` passed with **17 files and 182 tests**. `npm run typecheck`, `npm run lint`, and `npm run build` also passed. These tests exercise the deterministic mock/demo service boundary, not a live backend.

## System and adversarial scope

The frontend runbook explicitly states that default production uses unavailable adapters and development uses mock services. Therefore the 182 frontend tests are not full-system evidence. The backend API has a development-only `X-Campus-Duo-Test-Actor` path; production identity verification is not claimed. Adversarial coverage includes actor format/eligibility, authorization, consent/blocking, validation, replay/idempotency and safe errors through the backend tests and frontend mock-service tests. Prompt-injection testing is not applicable because no agent tool execution surface exists.

## Evidence classification

| Area | Result |
|---|---|
| Backend unit/integration | Verified by post-review evidence |
| Current backend mocked/unit subset | Verified, 29/29 on 6 November 2026 |
| Current isolated health integration | Verified, 1/1 against explicit `campus_duo_test` target |
| Current full DB-backed backend suite | Blocked by missing migrator credential |
| Backend real PostgreSQL concurrency | Verified, 10-request race; see concurrency report |
| Frontend unit/component | Verified, 182/182 |
| Browser visual/system | Not executed |
| Real frontend-to-backend journey | Blocked by adapter/auth boundary |
| PostgreSQL restart recovery | Not executed |
| Performance/load | Pending credentials and provisioning |
