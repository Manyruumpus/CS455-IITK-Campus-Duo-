# Costing Document

**Currency/region/date:** INR/India assumptions; 3 November 2026. Exact provider prices were not re-verified in this session, so hosted figures are estimates, not quotations.

| Cost category | Current status | Assumption |
|---|---|---|
| Local development, Node, PostgreSQL, k6, Flyway | Sunk cost / ₹0 incremental | Existing workstation and already-installed tools |
| Local test database and fixtures | ₹0 incremental | Existing local PostgreSQL; no service provisioning |
| Hosted PostgreSQL | Estimate pending provider/region choice | Select a small managed instance and storage/backup tier after deployment decision |
| Hosted app runtime | Estimate pending provider/region choice | One small development service; scale/availability not yet selected |
| Observability, email, push, LLM | Optional/not purchased | No production delivery or agent service was provisioned |

No cloud purchase, hosted service, or subscription is claimed. Before submission, replace pending estimates with dated provider pricing, region, free-tier limits, storage/egress assumptions, and expected monthly usage if the team has selected a deployment target.

