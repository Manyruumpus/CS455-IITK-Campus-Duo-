# Final Traceability Matrix

Jira remains externally unverified. Read-only GitHub evidence was available for
the merged booking-concurrency pull request; all other GitHub references below
remain local-only or unverified.

| Requirement | Jira | GitHub/commit | Test/evidence | Status |
|---|---|---|---|---|
| NFR-06 daily capacity model | UNVERIFIED | Performance harness files | `KAN-81-performance-load-report.md` | Partial; no load result |
| NFR-07 p95/throughput budgets | UNVERIFIED | Performance harness files | Report labels p95 as provisional and throughput pending approval | Partial |
| Booking conflict correctness | KAN-36 / verify live key | [PR #2](https://github.com/Manyruumpus/CS455-IITK-Campus-Duo-/pull/2), commit `500f9e5d73e0a232113ba4ec27e643a53fd7a940` | `booking-concurrency-isolated.json` | Verified GitHub link; Jira key still unverified |
| Availability correctness | KAN-71 / verify live key | `b0db123` | `KAN-71-availability-fixed-run-*.json` | Verified |
| Runtime dependency security | KAN-70 / verify live key | `b9807f5` | dependency before/after artifacts | Verified |
| Backend regression/coverage | KAN-79/KAN-81 / verify live keys | current worktree | post-review backend test and coverage evidence | Verified checkpoint |
| Frontend automated quality | UNVERIFIED | current worktree | 182 tests, typecheck, lint, build in this session | Verified locally |
| Real frontend/backend system journey | UNVERIFIED | UNVERIFIED | No live adapter/browser evidence | Blocked |
| Failure/restart recovery | UNVERIFIED | UNVERIFIED | Mock health failure only | Blocked |
| Deployment/costing | UNVERIFIED | UNVERIFIED | Runbook and estimate document | Partial |
