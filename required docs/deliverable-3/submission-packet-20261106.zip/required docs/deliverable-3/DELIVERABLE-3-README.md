# Deliverable 3 Evidence Index

**As of:** 6 November 2026  
**Repository:** `Manyruumpus/CS455-IITK-Campus-Duo-`  
**Worktree:** dirty; unrelated frontend/generated command-like artifacts are intentionally excluded.

## Verified

- Backend: 57 tests across 9 files, with post-review evidence in `evidence/backend-tests/KAN-81-backend-post-review-20261103-162511-954-05681db0.json`.
- Backend coverage: statements 90.98%, branches 87.65%, functions 82.50%, lines 91.66%; see `evidence/backend-coverage/KAN-81-post-review-20261103-162511-954-05681db0/`.
- Frontend: 17 files, 182 tests passed on 3 November 2026; typecheck, lint, and production build passed in this session.
- Backend build passed in this session.
- Current backend mocked/unit subset: 29/29 passed; isolated health integration:
  1/1 passed with explicit `campus_duo_test` targeting. Current evidence is in
  `evidence/backend-tests/current-mocked-unit-check-20261106.json` and
  `evidence/backend-tests/current-health-isolated-20261106.json`.
- Dependency before/after artifacts: `evidence/dependency-audit/`.
- Concurrency and availability evidence: `evidence/backend-tests/booking-concurrency-isolated.json`, `KAN-71-availability-fixed-run-1.json`, and `KAN-71-availability-fixed-run-2.json`.

## Partial or blocked

- Real performance provisioning/smoke/baseline: blocked pending interactive database credentials and target migration execution. No performance measurement is claimed.
- Backend rerun in this session: blocked by missing `CAMPUS_DUO_MIGRATOR_PASSWORD` and an application connection to `campus_duo_dev`; the failure is preserved, not counted as success.
- Browser/system integration: frontend defaults to mock services or an unavailable production adapter; no browser binary was installed and no real UI-to-PostgreSQL journey is claimed.
- PostgreSQL restart recovery: not executed; existing health failure tests use mocked boundaries.
- Jira dashboard/project status, live issue links, and Jira-GitHub integration: repository state is unverified and no external writes were made.
- Submission packet: `submission-packet-20261106.zip`; checksum:
  `submission-packet-20261106.zip.sha256`.

## Reports

| Artifact | Scope |
|---|---|
| `testing-report.md` | Unit, integration, system, adversarial scope and results |
| `coverage-report.md` | Backend coverage denominators and frontend test scope |
| `concurrency-report.md` | Real PostgreSQL booking race evidence |
| `security-threat-model.md` | Threats, controls, residual risks |
| `KAN-81-performance-load-report.md` | Harness, provisioning status, pending measurements |
| `failure-recovery-report.md` | Recovery evidence and blocked exercises |
| `defect-evidence-register.md` | Supported defect/weakness history |
| `costing.md` | Local sunk cost, hosted cost assumptions, unverified estimates |
| `timeline-gantt.md` | Actual evidence dates and remaining planned work |
| `deployment-runbook.md` | Local setup, migration, startup and rollback procedure |
| `traceability-matrix.md` | Requirement → Jira → GitHub → test → evidence |
| `jira-status-report.md` | External-record status and no-write limitation |
| `ai-engineering-log.md` | Deliverable 3 AI activity supplement |
