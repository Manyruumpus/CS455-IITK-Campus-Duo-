# Defect and Weakness Evidence Register

Only supported cases are listed; harness mistakes and unexecuted hypotheses are excluded.

| Case | Impact | Before/reproduction | Fix/retest evidence | Jira/Git reference |
|---|---|---|---|---|
| Runtime dependency vulnerabilities | High security exposure | Dependency audit baseline showed vulnerable runtime packages | Dependency patch and after-audit artifacts | KAN-70, `b9807f5` |
| Availability tests depended on seed dates | Medium false failures | Valid tests requested 2026-11-14 while seeded slots were 2026-11-11 | Owned deterministic fixture, date/location isolation, retained seven tests | KAN-71, `b0db123` |
| Booking concurrency cleanup could overlap fixtures | High test contamination risk | Shared/prefix cleanup could remove another run’s rows | Disjoint fixture ranges and scoped cleanup evidence | KAN-36, `500f9e5` |
| Test target/credential safety was weak | High data-integrity risk | Tests could point at development DB or run without explicit migrator credential | Exact `campus_duo_test`/role guards and fail-closed password checks | Current helper changes; post-review evidence |
| Performance provisioning accepted zero migrations | High false-success risk | Relative Flyway location resolved to `database\\database\\migrations`, then app password was unset | Absolute path, V001–V008 inventory, fail-on-missing, history/table completion checks, separate app password | Current performance harness changes; runtime retest pending |
| Runtime privilege boundary | High authorization impact | Broad/implicit access would violate migration/runtime separation | V008 explicit role/table grants and privilege verification scripts | V008, DB-07 evidence |

The first four cases are verified historical fixes. The performance provisioning issue is reproduced and fixed statically, but runtime migration success remains pending. The privilege-boundary case is supported as a security weakness fixed by the migration/evidence; its original exploit reproduction is not separately re-executed here.

