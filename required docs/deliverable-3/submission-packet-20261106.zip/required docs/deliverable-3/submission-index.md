# Campus Duo — CS455 Deliverable 3 Submission Index

**Checkpoint:** 6 November 2026  
**Repository:** `Manyruumpus/CS455-IITK-Campus-Duo-`  
**Branch at checkpoint:** `fix/d3-backend-dependency-security`  
**HEAD at checkpoint:** `b9807f5e773892ce955bca417cc21ae68eb6e67e`  
**Worktree:** dirty; current-revision evidence is explicitly labeled.

This index maps the required submission areas to the strongest local evidence
available at this checkpoint. It does not claim live Jira state, hosted
deployment, performance measurements, or infrastructure recovery where those
were not executed.

| # | Requirement | Status | Primary artifact/evidence |
|---:|---|---|---|
| 1 | Unit, integration, system, adversarial testing | PARTIAL | `testing-report.md`; historical 57-test JSON; current 29-test and health JSON; frontend 182-test checkpoint |
| 2 | Code coverage | PARTIAL | `coverage-report.md`; preserved post-review backend coverage; current subset summary |
| 3 | Concurrency | COMPLETE | `concurrency-report.md`; `evidence/backend-tests/booking-concurrency-isolated.json` |
| 4 | Security/threat model | PARTIAL | `security-threat-model.md` |
| 5 | Performance/load and optimization | BLOCKED | `KAN-81-performance-load-report.md`; harness only; no measurements |
| 6 | Failure/recovery | PARTIAL | `failure-recovery-report.md`; mocked recovery only |
| 7 | Jira defect history | UNVERIFIED | `jira-status-report.md`; live Jira not locally verifiable |
| 8 | Five fixed defects | PARTIAL | `defect-evidence-register.md`; four meet the strict evidence standard |
| 9 | Costing | PARTIAL | `costing.md`; provider/region pricing remains pending |
| 10 | Timeline/Gantt | PARTIAL | `timeline-gantt.md`; status sequence, not a fully rendered Gantt |
| 11 | Deployment documentation | PARTIAL | `deployment-runbook.md`; local procedure, no hosted deployment proof |
| 12 | Requirements-to-Jira-to-GitHub-to-testing traceability | PARTIAL | `traceability-matrix.md`; PR #2/commit `500f9e5d73e0a232113ba4ec27e643a53fd7a940` verified, Jira remains unverified |
| 13 | Jira dashboard/project report | UNVERIFIED | `jira-status-report.md`; draft layout only |
| 14 | AI Engineering Log | PARTIAL | `ai-engineering-log.md`; reconstructed local supplement |

## Current verification

- Frontend: 17 files, 182 tests passed; typecheck, lint, and production build
  passed on 6 November 2026.
- Backend build passed on 6 November 2026.
- Backend mocked/unit subset: 4 files, 29/29 passed.
- Backend isolated health integration: 1/1 passed with explicit
  `campus_duo_test` targeting.
- Full DB-backed backend rerun: blocked by missing
  `CAMPUS_DUO_MIGRATOR_PASSWORD`.
- Frontend coverage: blocked because `@vitest/coverage-v8` is not installed.
- Performance: blocked because administrator target-state credentials and a
  Flyway executable are unavailable; no load result is claimed.

## External/manual actions still required

1. Provide or locally install Flyway and run the guarded performance
   provisioning path with interactive credentials.
2. Execute smoke, baseline, and equivalent optimization comparison.
3. Execute real isolated PostgreSQL interruption/recovery testing.
4. Obtain authoritative Jira issue/dashboard/project evidence.
5. Add one fully evidenced fixed defect to reach five.
6. Add frontend coverage and complete costing/Gantt details.
